@echo off
if not exist "%~dp0uninstall-gpt-image-mcp.ps1" (
    echo.
    echo [ERROR] uninstall-gpt-image-mcp.ps1 not found.
    echo Extract the ZIP file first, then run uninstall.bat inside the extracted folder.
    echo.
    pause
    exit /b 1
)
rem a 32-bit program that starts this file gets the 32-bit PowerShell; Sysnative reaches the 64-bit one
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall-gpt-image-mcp.ps1"
set "RC=%ERRORLEVEL%"
echo.
pause
exit /b %RC%
